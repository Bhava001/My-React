import React from 'react'

function B() {
  return (
    <>
    <h1>
      B
    </h1>
    </>
  )
}

export default B