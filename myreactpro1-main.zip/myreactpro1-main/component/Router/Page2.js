import React from 'react'

function Page2() {
  return (
    <div>Page2</div>
  )
}

export default Page2