import React from 'react'

function A() {
  return (
    <>
    <h1>
        A
    </h1>
    </>
  )
}

export default A