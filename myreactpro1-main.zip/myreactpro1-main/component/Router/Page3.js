import React from 'react'

function Page3() {
  return (
    <div>Page3</div>
  )
}

export default Page3