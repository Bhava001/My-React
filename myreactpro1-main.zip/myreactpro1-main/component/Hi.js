import React from 'react'

function Hi() {
  return (
    <>
    <button>
        <h3>
            Hi
        </h3>

    </button>
    
    
    
    </>
  )
}

export default Hi