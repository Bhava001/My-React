import React from 'react'

function Home() {
  return (
    <>
    <button>
      <h1>Home</h1>
    </button>
    
    </>
  )
}

export default Home