import React from 'react'

function Blogs() {
  return (
    <>
    <button>
      <h1>Blogs</h1>
    </button>
    
    </>
  )
}

export default Blogs