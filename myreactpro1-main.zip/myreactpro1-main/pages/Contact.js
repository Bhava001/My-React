import React from 'react'

function Contact() {
  return (
    <>
    <button>
      <h1>Contact</h1>
    </button>
    
    </>
  )
}

export default Contact