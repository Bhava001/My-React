import React from 'react'
import Imgnavmu from './Imgnavmu';


function Home() {
  return (
    <>
      <Imgnavmu />
    </>
  )
}

export default Home